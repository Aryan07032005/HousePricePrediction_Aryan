# House Price Prediction Using Machine Learning

## Submitted By

**Name:** Aryan

---

# Abstract

House price prediction is an important application of machine learning in the real estate industry. Predicting the selling price of a house helps buyers, sellers, investors, and property developers make informed decisions.

In this project, a Machine Learning Regression model is developed using Python and Scikit-learn. The Housing dataset is cleaned, analyzed, visualized, and used to train a Linear Regression model. The model predicts house prices based on different housing features such as area, number of bedrooms, bathrooms, stories, parking facilities, air conditioning, and furnishing status.

The project includes data preprocessing, exploratory data analysis, feature engineering, model building, model evaluation, prediction, and visualization.

---

# Objectives

The objectives of this project are:

- Predict house prices accurately.
- Understand relationships between house features and price.
- Perform Exploratory Data Analysis (EDA).
- Train a Linear Regression model.
- Evaluate model performance.
- Save the trained model using Joblib.
- Build a complete machine learning workflow.

---

# Introduction

Machine Learning enables computers to learn patterns from historical data and make predictions without explicit programming.

House price prediction is a supervised machine learning regression problem because the target variable (price) is continuous.

The project uses the Housing dataset containing multiple house characteristics.

The workflow includes:

- Data Collection
- Data Cleaning
- Data Visualization
- Feature Encoding
- Model Training
- Model Testing
- Performance Evaluation
- Saving the Model

# Literature Survey

Several machine learning techniques have been applied for house price prediction. Linear Regression is one of the most widely used algorithms because it is simple, fast, and provides good results when the relationship between variables is approximately linear.

Researchers have also explored Decision Trees, Random Forests, Support Vector Regression, and Gradient Boosting methods. These advanced models often improve prediction accuracy but require more computational resources.

In this project, Linear Regression was selected due to its simplicity, interpretability, and effectiveness for the given dataset.

---

# Dataset Description

The Housing dataset contains information about different residential properties.

Some important features include:

- Price
- Area
- Number of Bedrooms
- Number of Bathrooms
- Number of Stories
- Main Road Access
- Guest Room Availability
- Basement Availability
- Hot Water Heating
- Air Conditioning
- Parking
- Preferred Area
- Furnishing Status

Target Variable:

**Price**

Independent Variables:

All remaining housing features.

---

# Software and Tools Used

The following software and libraries were used:

- Python
- Jupyter Notebook
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- Joblib

---

# Methodology

The project follows the standard Machine Learning pipeline.

## Step 1: Data Collection

The Housing dataset is loaded into Pandas.

## Step 2: Data Cleaning

Missing values are checked and categorical variables are converted into numerical values.

## Step 3: Exploratory Data Analysis

Graphs and correlation heatmaps are generated to understand relationships between variables.

## Step 4: Feature Selection

Independent variables are selected while the Price column is used as the target.

## Step 5: Train-Test Split

The dataset is divided into training and testing sets using an 80:20 ratio.

## Step 6: Model Training

A Linear Regression model is trained using Scikit-learn.

## Step 7: Model Evaluation

Performance is evaluated using:

- Mean Absolute Error (MAE)
- Mean Squared Error (MSE)
- R² Score

## Step 8: Model Saving

The trained model is saved using Joblib for future predictions.

# Exploratory Data Analysis (EDA)

Exploratory Data Analysis (EDA) was performed to understand the dataset before training the machine learning model.

The following analyses were carried out:

- Displayed the first few rows of the dataset.
- Checked dataset dimensions.
- Verified data types of all columns.
- Checked for missing values.
- Generated summary statistics.
- Visualized feature distributions using histograms.
- Created a correlation heatmap.
- Compared important variables using scatter plots and box plots.

These visualizations helped identify the relationships between housing features and house prices.

---

# Model Evaluation

The Linear Regression model was evaluated using standard regression metrics.

## Mean Absolute Error (MAE)

Measures the average absolute difference between predicted and actual prices.

## Mean Squared Error (MSE)

Measures the average squared prediction error.

## R² Score

Represents how well the model explains the variance in house prices.

A higher R² score indicates better model performance.

---

# Results

The trained Linear Regression model successfully learned the relationship between housing features and house prices.

The model produced reasonable predictions on the testing dataset.

The evaluation metrics indicated satisfactory prediction performance for the given dataset.

The trained model was saved using Joblib, allowing it to be reused without retraining.

---

# Advantages

- Easy to implement.
- Fast training time.
- Easy to interpret.
- Suitable for continuous value prediction.
- Can be reused for future predictions.

---

# Limitations

- Assumes a linear relationship between variables.
- Sensitive to outliers.
- Performance may decrease on highly complex datasets.
- Cannot model strong nonlinear relationships.

---

# Future Scope

The project can be improved by:

- Using larger datasets.
- Applying Random Forest Regression.
- Using XGBoost or Gradient Boosting.
- Building a web application using Flask or Streamlit.
- Deploying the model on cloud platforms.
- Adding real-time property prediction functionality.

---

# Conclusion

This project demonstrates the complete workflow of a Machine Learning regression problem using Python.

Starting from data preprocessing and visualization, the project proceeds through feature engineering, model training, evaluation, and model saving.

Linear Regression proved to be an effective baseline model for predicting house prices.

The project provides practical experience in data analysis, machine learning, and predictive modeling.

---

# References

1. Scikit-learn Documentation
2. Pandas Documentation
3. NumPy Documentation
4. Matplotlib Documentation
5. Seaborn Documentation
6. Housing Dataset (Kaggle)
7. Python Official Documentation

---

# Acknowledgement

I sincerely thank my project guide, faculty members, and institution for their continuous support and guidance throughout this project.

I also acknowledge the open-source Python community for providing excellent tools and libraries that made this project possible.