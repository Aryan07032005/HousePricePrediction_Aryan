# House Price Prediction using Machine Learning

## Project Overview

This project predicts house prices using Machine Learning algorithms. It demonstrates the complete machine learning pipeline from data preprocessing to model deployment.

The project is developed using Python in Jupyter Notebook.

---

## Dataset

Dataset Name: Housing.csv

The dataset contains various features affecting house prices, including:

- Area
- Bedrooms
- Bathrooms
- Stories
- Main Road
- Guest Room
- Basement
- Hot Water Heating
- Air Conditioning
- Parking
- Preferred Area
- Furnishing Status
- Price (Target Variable)

---

## Technologies Used

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Scikit-learn
- Joblib
- Jupyter Notebook

---

## Machine Learning Algorithms

The following algorithms were implemented:

- Linear Regression
- Random Forest Regressor

---

## Project Workflow

1. Import Libraries
2. Load Dataset
3. Data Exploration
4. Data Cleaning
5. Feature Engineering
6. Exploratory Data Analysis
7. Train-Test Split
8. Model Training
9. Model Evaluation
10. Model Comparison
11. Feature Importance
12. Model Saving
13. Prediction

---

## Performance Metrics

The models were evaluated using:

- Mean Absolute Error (MAE)
- Mean Squared Error (MSE)
- Root Mean Squared Error (RMSE)
- R² Score

---

## Folder Structure

HousePricePrediction_Aryan/

├── HousePricePrediction.ipynb

├── data/

│ └── Housing.csv

├── model/

│ └── house_price_model.pkl

├── charts/

├── report/

└── README.md

---

## Future Improvements

- Hyperparameter Tuning
- Cross Validation
- XGBoost Regression
- Gradient Boosting
- Web Application using Flask

---

## Author

Aryan

Machine Learning Project

